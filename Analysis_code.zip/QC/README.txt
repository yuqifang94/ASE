The files in this folder contains the QC analysis for bam files
converage_calc.sh: extract the coverage for each CpG based on the input bed and bam files
mbias.sh: generate mbias plot for each bam files