This folder contains all the script that generate the region samples for CPEL analysis and read the outputs
bin_enhancer_read.R: read in the supplmentary table 8c from PMID:32728240
counting_ASM.R: count number of ASM events
CPEL_submission_file_gen.R: generating the submission file for NME, MML and UC calculation for CPEL
gff_file_generation.R: generating gff file based for CPEL analysis for human and mouse
pre_process_CPEL.R: reading in UC, NME, MML and merge them into R object
bedGraph_to_bw.sh: convert bedGraph files to bigwig files for submission