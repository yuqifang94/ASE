This folder contains the files that generate mouse analysis under different UC cutoffs, the clustering result is from mouse_clustering_analysis folder
cutoff_test.R: contains the code to generate data for clustering, correlation and GO analysis for different cutoffs
cutoff_plot.R: contains the code to generate the figure for clustering, correlation and GO analysis for different cutoffs
cutoff_test_submission.sh: contains the submission files for cutoff_test.R
fulldmmldnmecor.R: contains code to generate the correlation between UC and NME or MML in all regions
fullpermudmmlcnme.R:contains code to generate the permutaed correlation between UC and NME or MML in all regions