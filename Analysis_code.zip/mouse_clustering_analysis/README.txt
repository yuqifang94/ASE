The files in the folder are used to generate Fig 5A, the MDS plot from Jason (Zhicheng) Ji
make.R: generating the clustering 10 times based on certain UC cutoff
make.sh: bash script submitting make.R for each UC cutoff
cluster_non_tissue_specific.R: clustering analysis using non-tissue-specific cutoff 
promoter_vs_enhancer_mouse.R: dNME and dMML comparison between enhancer and promoter
region_count_non_ts_heatmap.R:count number of region that only in 1 tissue or shared and heatmap generation