for i in 0.01 0.05 0.2 0.3 0.4 0.5
do
qsub make.sh $i
done
