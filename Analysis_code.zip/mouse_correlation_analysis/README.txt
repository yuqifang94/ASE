The files in this folder is for mouse GO and correaltion analysis 
correlation.R: assigning the major clusters, plotting heatmap for Fig 5B and assigning clusters plotting for Fig 5D
mouse_GO_analysis.R: GO analysis for each cluster and each correlation catogries for Fig 5C and supplmentary Figs