This folder contains all the script for human and mouse MAV analysis
The following files are from Zicheng(Jason) Ji
c1_cv.R: calculation of coefficient of variant (CV) for mouse
c1_saver.R: calculate MAV using scRNA data from C1 with saver pre-processing for mouse
human_MAV.R: calculate MAV using human scRNA data for matched tissue
The following files are from Yuqi Fang
human_NME_MAV.R: using MAV and NME, MML to generate Fig 7, Fig S17 and calculate correlation for human
mouse_NME_MAV.R: using MAV and NME, MML to generate Fig S18 for mouse 